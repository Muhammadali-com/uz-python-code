UZCODEPACKAGE SAYTINI INFINITYFREE'GA YUKLASH

1. InfinityFree boshqaruv panelidan File Manager'ni oching.
2. Saytning htdocs papkasiga kiring.
3. Ushbu site papkasi ichidagi fayl va papkalarni htdocs ichiga yuklang. Site papkasining o'zini htdocs ichiga ichma-ich joylamang.
4. index.html htdocs ichida bevosita turishi kerak.
5. assets papkasi ham index.html bilan bir darajada bo'lishi kerak.
6. Domeningizni ochib tekshiring.

Sayt statik HTML/CSS sahifalaridan iborat. Python paketi InfinityFree saytida ishlamaydi; paketni PyPI orqali tarqatish alohida jarayon.
